# FCM Test Plan

## Scope

This plan covers:

- token registration from `FittyFirebaseMessagingService.onNewToken`
- remote notification display via `FittyFirebaseMessagingService.onMessageReceived`
- in-app persistence through `FittyNotificationDispatcher`
- real push delivery from Firebase Cloud Messaging

## Preconditions

- App installed on a physical Android device with Google Play Services.
- Device signed into the same Firebase project used by the app.
- Notification permission granted on Android 13+.
- Valid service account JSON configured in `.env` as `FIREBASE_SERVICE_ACCOUNT_PATH`.
- A current device FCM token copied from the app or from Firestore `users/{uid}/notification_tokens`.

## Local Automated Coverage

- `RoomAppNotificationRepositoryTest`
  verifies notifications switch owner scope when the session changes.
- `RoomHomeTaskRepositoryTest`
  verifies task reminders switch owner scope when the session changes.
- `ConfirmMealLogUseCaseTest`
  verifies backfilled logs update the correct summary date.
- `WorkoutSessionUseCasesTest`
  verifies workout completion fails fast when scheduled-workout status update fails.

## Real Push Test

Run:

```bash
node scripts/send_fcm_test.mjs --token "<device_fcm_token>" --title "Fitty smoke" --body "Firebase push path is working"
```

Optional:

```bash
node scripts/send_fcm_test.mjs \
  --token "<device_fcm_token>" \
  --title "Fitty workout reminder" \
  --body "Open the app and verify banner + tray notification" \
  --route "home"
```

## Expected Results

When the app is backgrounded:

- Android system tray notification appears.
- Opening the notification launches the app.
- A new record is persisted in local app notifications.

When the app is foregrounded:

- In-app banner appears through `FittyBannerController`.
- Notification may still post to tray if permission exists.
- A new record is persisted in local app notifications.

## Validation Checklist

1. Open `Profile` in a debug build and use `Push Debug > Load token`, then copy the token.
2. Send push with `send_fcm_test.mjs`.
3. Confirm notification title/body match payload.
4. Open Home and confirm the notification list contains the new item.
5. Log out and log back in with another user.
6. Confirm notification list is owner-scoped and does not leak previous user data.
7. Rotate timezone or reboot device.
8. Confirm reminder notifications still reschedule correctly.

## Failure Triage

- `401` or `403` from script:
  service account or Firebase IAM permissions are wrong.
- `404 UNREGISTERED`:
  device token is stale; reopen app to refresh token.
- token does not load in `Profile`:
  verify Google Play Services is available, Firebase is initialized, and the device has network access.
- push sent but no device notification:
  check notification permission, channel settings, OEM battery restrictions, and whether the app is foregrounded.
- app stores no notification entry:
  inspect `FittyNotificationDispatcher` and local notification repository owner scoping.
