# Exercise Streaming Architecture

## Overview

This app uses an offline-first metadata architecture and on-demand video streaming:

```text
API -> Retrofit -> OfflineFirstExerciseRepository -> Room -> ViewModel -> Compose UI
                                       |
                                       +-> Coil thumbnail caching
                                       +-> Media3 / ExoPlayer streaming
                                       +-> Optional single-video offline download
                                       +-> WorkManager background sync
```

## Why streaming

- Keeps APK size small because videos are not bundled.
- Saves user storage because only metadata is stored permanently.
- Supports adaptive bitrate streaming through HLS / DASH.
- Matches production behavior used by fitness, learning, and media apps.

## Local storage policy

- `Room`: exercise metadata, favorite state, recent history, sync metadata.
- `filesDir`: optional user-requested offline video files and persisted thumbnails.
- `cacheDir`: temporary download buffers and short-lived media temp files.

## Internal storage vs cache storage

- `filesDir` is for persistent private app files. Use this for downloaded offline videos.
- `cacheDir` is for disposable app-private files. Android may delete it under pressure.

## Backend recommendations

- Return metadata from `/v1/exercises`.
- Return `thumbnailUrl` and `videoUrl` fields.
- Prefer HLS manifests for `videoUrl`.
- Add `updatedAt`, `version`, and `deltaToken` for delta sync.
- Secure videos using signed URLs:
  - Firebase Storage: short-lived download tokens or callable backend.
  - AWS S3 / CloudFront: presigned URLs or signed cookies.
  - Cloudflare R2: signed access through backend gateway.

## Security

- Never embed public long-lived media URLs directly in the APK.
- Prefer short-lived signed URLs issued by your backend after auth validation.
- Restrict storage rules to authenticated users and authorized paths.
- Rotate signing keys and log access attempts.

## Scaling notes

- Use paginated metadata sync.
- Only cache thumbnails automatically.
- Download video files only on explicit user action.
- Use WorkManager for background metadata refresh.
- Use Room as the single source of truth.
