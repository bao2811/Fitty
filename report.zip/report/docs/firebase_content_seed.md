# Firebase Content Seed

## Mục đích

Seed dữ liệu cho các collection content mới mà app đang đọc:

- `app_content/home`
- `app_content/coach`
- `app_content/practice_categories/items`
- `app_content/exercise_prescriptions/items`
- `starter_plan_templates`

File seed chuẩn nằm tại:

```text
scripts/firebase_content_seed.json
```

## Chạy seed

Repo đã dùng `.env` hiện tại với:

- `FIREBASE_PROJECT_ID`
- `FIREBASE_SERVICE_ACCOUNT_PATH`

Chạy:

```bash
node scripts/seed_firebase_content.mjs
```

Tuỳ chọn:

```bash
node scripts/seed_firebase_content.mjs --seed scripts/firebase_content_seed.json --project-id fir-18934
```

## Dữ liệu đang được đẩy

### `app_content/home`

- `translations.en`
- `translations.vi`
- `emptyState`
- `insightActions`
- `suggestedTaskPresets`
- `defaultTaskTemplates`

### `app_content/coach`

- `translations.en`
- `translations.vi`
- `welcomeMessage`
- `promptChips`

### `app_content/practice_categories/items/*`

- `id`
- `bodyPartKeys`
- `assetImage`
- `cardColor`
- `order`
- `labels.en`
- `labels.vi`

### `starter_plan_templates/*`

- `goal`
- `fitnessLevels`
- `equipments`
- `translations.en`
- `translations.vi`
- `planMeta`
- `scheduledWorkoutTemplates`

### `app_content/exercise_prescriptions/items/*`

- `exerciseId`
- `translations.en.note`
- `translations.vi.note`
- `rules[*].goal`
- `rules[*].fitnessLevels`
- `rules[*].equipments`
- `rules[*].minWeightKg`
- `rules[*].maxWeightKg`
- `rules[*].sets`
- `rules[*].reps`
- `rules[*].durationSeconds`
- `rules[*].targetWeightMode`
- `rules[*].fixedTargetWeightKg`
- `rules[*].bodyWeightMultiplier`
- `rules[*].minSuggestedWeightKg`
- `rules[*].maxSuggestedWeightKg`

## Cách hoạt động của prescription

- App tìm prescription theo `exerciseId`.
- Nếu có nhiều rule, app chọn rule khớp nhất với hồ sơ hiện tại của user:
  - `goal`
  - `fitnessLevel`
  - `equipment`
  - `weightKg` nằm trong `minWeightKg..maxWeightKg`
- `targetWeightMode` hỗ trợ:
  - `none`
  - `bodyweight`
  - `upper_body`
  - `lower_body`
- Có thể ép mức tạ cố định bằng `fixedTargetWeightKg`, hoặc tính từ cân nặng hiện tại của user bằng `bodyWeightMultiplier`.
- `minSuggestedWeightKg` và `maxSuggestedWeightKg` dùng để chặn mức tạ gợi ý trong khoảng an toàn.

## Ghi chú vận hành

- App vẫn có local fallback nếu Firestore thiếu dữ liệu hoặc offline.
- Có thể chỉnh tay trực tiếp trên Firestore sau khi seed.
- Khi thêm field mới cho content schema, cần cập nhật đồng thời:
  - `FirebaseContentRepository`
  - `LocalContentFallbacks`
  - `scripts/firebase_content_seed.json`

## Kiểm tra sau seed

1. Mở `Home`, `Coach`, `Plan`, `Plan Preview`, `Category Exercise List`, `Exercise Detail`.
2. Đổi language `en/vi`.
3. Xác nhận nội dung đổi theo Firestore.
4. Đổi cân nặng hoặc mức độ tập trong hồ sơ user rồi mở lại bài tập để xác nhận `set/rep/weight` đổi theo rule.
5. Tắt mạng để xác nhận fallback local vẫn hoạt động.
