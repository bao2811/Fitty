# Fitty Report Support

Tài liệu này tổng hợp nhanh những gì đang có trong repo để phục vụ viết báo cáo theo mẫu LaTeX ở thư mục `chapters/`.

## 1. Bài toán và phạm vi đề tài

`Fitty` là ứng dụng Android hỗ trợ người dùng xây dựng và theo dõi kế hoạch tập luyện cá nhân hóa. Dự án tập trung vào các luồng chính:

- đăng ký, đăng nhập, dùng thử guest
- onboarding để thu thập mục tiêu, thể trạng và thói quen tập
- sinh kế hoạch tập khởi đầu và lịch bài tập theo hồ sơ người dùng
- tra cứu bài tập theo nhóm cơ, xem media hướng dẫn và bài tập chi tiết
- thực hiện buổi tập nhanh hoặc buổi tập theo lịch
- theo dõi dinh dưỡng, cân nặng, tiến độ luyện tập
- thông báo cục bộ và thông báo đẩy Firebase Cloud Messaging
- đồng bộ nội dung động từ Firebase và dữ liệu bài tập theo kiến trúc offline-first

## 2. Stack công nghệ

Từ `app/build.gradle.kts`, dự án đang dùng:

- Android SDK 36, minSdk 24
- Kotlin + Jetpack Compose
- Navigation Compose
- Hilt để DI
- Room để lưu trữ cục bộ
- DataStore cho preferences/session
- Firebase Auth, Firestore, Storage, Messaging, Analytics
- Retrofit + OkHttp + Gson
- WorkManager cho đồng bộ nền
- Coil cho ảnh/GIF
- Media3 / ExoPlayer cho video

## 3. Kiến trúc hệ thống

Kiến trúc thực tế trong repo là dạng nhiều tầng:

- `feature_*`: tầng giao diện và luồng người dùng
- `domain/model`, `domain/repository`, `domain/usecase`: mô hình nghiệp vụ, interface và use case
- `data/firebase`: tích hợp Firebase
- `data/local`: Room database, DAO, repository local
- `data/exercise`: đồng bộ metadata bài tập, media cache, worker
- `navigation`: điều hướng toàn app
- `di/AppModule.kt`: cấu hình dependency injection

Điểm kiến trúc nổi bật:

- nội dung bài tập dùng kiến trúc offline-first:
  API/Firestore -> repository -> Room -> ViewModel -> Compose UI
- thumbnail/media được cache cục bộ, video có thể stream hoặc tải về theo nhu cầu
- dữ liệu sản phẩm như onboarding options, practice categories, starter plan template, exercise prescription được quản lý từ Firebase content

## 4. Các tài liệu nguồn đã có trong repo

### Tài liệu mô tả và kế hoạch

- `description.md`: mô tả dài về dự án
- `baitap.md`: ghi chú yêu cầu bài tập
- `plan.md`: audit UI, dữ liệu giả, các phần còn cần hoàn thiện
- `implementation_plan.md`: kế hoạch cải tiến Quick Workout và Exercise Detail
- `planB.md`, `guild.md`, `note.txt`, `ab.txt`: tài liệu làm việc nội bộ, có thể khai thác thêm nếu cần chi tiết diễn tiến

### Tài liệu kỹ thuật

- `docs/exercise-streaming-architecture.md`: kiến trúc metadata offline-first, cache ảnh/video
- `docs/firebase_content_schema.md`: schema content trên Firebase
- `docs/firebase_content_seed.md`: quy trình seed dữ liệu content
- `docs/fcm_test_plan.md`: kế hoạch kiểm thử thông báo đẩy

### Tài liệu báo cáo LaTeX

- `thesis.tex`: file gốc ghép toàn bộ luận văn
- `cover.tex`: bìa
- `chapters/c1/c1_introduction.tex`: mẫu chương 1
- `chapters/c2/c2_chapter.tex`: mẫu chương 2
- `chapters/c3/c3_chapter.tex`: mẫu chương 3
- `chapters/c4/c4_chapter.tex`: mẫu chương 4
- `chapters/conclusion.tex`: kết luận

## 5. Các phân hệ chính nên đưa vào báo cáo

### 5.1 Xác thực và khởi động ứng dụng

Nguồn chính:

- `MainActivity.kt`
- `feature_auth/*`
- `feature_entry/*`
- `navigation/FittyNavHost.kt`
- `data/firebase/FirebaseAuthRepository.kt`
- `data/firebase/FirebaseStartupRepository.kt`

Nội dung nên viết:

- luồng Splash -> Welcome / SignIn / Onboarding / Main
- đăng nhập email-password, Google, guest
- xác định trạng thái khởi động dựa trên đăng nhập và onboarding

### 5.2 Onboarding và sinh kế hoạch khởi đầu

Nguồn chính:

- `feature_onboarding/*`
- `data/firebase/FirebaseOnboardingRepository.kt`
- `data/firebase/FirebaseUserRemoteDataSource.kt`
- `data/content/StarterPlanBuilder.kt`
- `scripts/firebase_content_seed.json`

Nội dung nên viết:

- dữ liệu thu thập từ onboarding
- cách ánh xạ câu trả lời người dùng thành hồ sơ tập luyện
- quy trình sinh starter plan, preview details, scheduled workouts

### 5.3 Quản lý bài tập và kiến trúc offline-first

Nguồn chính:

- `data/exercise/OfflineFirstExerciseRepository.kt`
- `data/exercise/ExerciseSyncWorker.kt`
- `data/exercise/ExerciseSyncScheduler.kt`
- `data/exercise/ExerciseMediaDownloadManager.kt`
- `data/remote/exercise/*`
- `docs/exercise-streaming-architecture.md`

Nội dung nên viết:

- đồng bộ metadata từ Firestore
- validate và normalize dữ liệu `bodyPart`
- cache thumbnail/media
- trạng thái sync và fallback khi offline

### 5.4 Kế hoạch tập, buổi tập và theo dõi tiến độ

Nguồn chính:

- `feature_plan/*`
- `feature_workout/*`
- `feature_track/*`
- `domain/model/PlanModels.kt`
- `domain/model/WorkoutSessionModels.kt`
- `domain/usecase/workout/WorkoutSessionUseCases.kt`
- `data/firebase/FirebasePlanRepository.kt`
- `data/firebase/FirebaseWorkoutSessionRepository.kt`
- `data/firebase/FirebaseTrackingRepository.kt`

Nội dung nên viết:

- mô hình `PlanInstance`, `ScheduledWorkout`, `WorkoutExercise`
- quick workout và scheduled workout
- lưu lịch sử hoàn thành buổi tập
- tổng hợp daily summaries, streak, workouts, meal logs

### 5.5 Thông báo và nội dung động

Nguồn chính:

- `notifications/*`
- `docs/fcm_test_plan.md`
- `docs/firebase_content_schema.md`
- `data/firebase/FirebaseContentRepository.kt`

Nội dung nên viết:

- local reminder cho task
- FCM token registration, push receive, persist notification local
- quản trị nội dung động trên Firebase

## 6. Gợi ý viết theo mẫu chapters

### Chương 1. Đặt vấn đề

Nên trình bày:

- bối cảnh nhu cầu cá nhân hóa luyện tập và theo dõi sức khỏe trên di động
- hạn chế của cách quản lý kế hoạch tập thủ công
- mục tiêu xây dựng ứng dụng Fitty
- phạm vi: Android app, Firebase backend services, nội dung tập luyện, theo dõi và thông báo
- cấu trúc báo cáo

### Chương 2. Nền tảng và công nghệ sử dụng

Nên đổi tiêu đề theo hướng hệ thống:

- Jetpack Compose
- Navigation Compose
- Hilt
- Room
- DataStore
- Firebase Auth / Firestore / Storage / FCM
- WorkManager
- Retrofit / OkHttp
- Media3 / ExoPlayer

Có thể thêm phần:

- mô hình offline-first
- nguyên lý push notification

### Chương 3. Phân tích và thiết kế hệ thống

Nên có:

- yêu cầu chức năng và phi chức năng
- use case chính
- kiến trúc tổng quan client + Firebase
- thiết kế dữ liệu:
  - user profile
  - onboarding
  - plan instances
  - scheduled workouts
  - notifications
  - exercise content
  - local Room tables
- biểu đồ tuần tự cho:
  - đăng nhập
  - onboarding và sinh starter plan
  - đồng bộ bài tập
  - hoàn thành buổi tập

### Chương 4. Cài đặt, kiểm thử và triển khai hệ thống

Nên có:

- môi trường cài đặt
- cấu trúc source code
- mô tả phần cài đặt chính:
  - auth flow
  - onboarding + plan preview
  - exercise sync
  - quick workout / scheduled workout
  - tracking
  - notifications
- kiểm thử:
  - unit test hiện có trong `app/src/test`
  - kịch bản kiểm thử FCM trong `docs/fcm_test_plan.md`
  - kiểm thử chức năng bằng các flow chính

## 7. Các bảng và hình nên chuẩn bị

- sơ đồ kiến trúc tổng thể ứng dụng
- sơ đồ navigation flow
- sơ đồ ER/collection cho Firebase + Room
- bảng chức năng từng phân hệ
- bảng công nghệ sử dụng và vai trò
- ảnh màn hình:
  - SignIn / SignUp
  - Onboarding
  - Plan Preview
  - Home
  - Plan / Category Exercise List
  - Workout Session
  - Track
  - Profile

## 8. Nhận xét hiện trạng template LaTeX

- `thesis.tex` đã được chỉnh theo hướng Unicode hiện đại để phù hợp hơn với `xelatex`
- MiKTeX đã được cài trên máy
- hiện chưa build trọn vẹn do MiKTeX không tải thêm package từ package server trong môi trường này
- nếu package server hoạt động, hướng build nên ưu tiên:

```powershell
C:\Users\Admin\AppData\Local\Programs\MiKTeX\miktex\bin\x64\xelatex.exe thesis.tex
```

## 9. Cách tôi có thể hỗ trợ tiếp

Ở bước sau, tôi có thể làm trực tiếp một trong các việc sau:

1. viết nháp Chương 1 bằng tiếng Việt dựa trên source và tài liệu hiện có
2. dựng khung Chương 2, 3, 4 thành nội dung LaTeX ngay trong `chapters/`
3. trích ra mô tả use case, kiến trúc và thiết kế dữ liệu từ code thành văn phong báo cáo
4. tiếp tục xử lý môi trường LaTeX nếu bạn muốn tôi chuyển sang một phương án cài đặt khác
