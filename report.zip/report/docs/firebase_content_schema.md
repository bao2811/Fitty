# Firebase Content Schema

This document defines the Firebase-managed content and behavior config that Fitty currently reads at runtime.

## Fallback order

Every remote-managed content path follows the same precedence:

1. requested language
2. `en`
3. `LocalContentFallbacks`

User-write workflows must not silently succeed when Firebase writes fail. Fallback only applies to read-time content/config.

## Collections

### `app_content/home`

Required fields:

- `translations.en.emptyState`
- `translations.vi.emptyState`
- `translations.en.insightActions`
- `translations.vi.insightActions`
- `translations.en.suggestedTaskPresets`
- `translations.vi.suggestedTaskPresets`
- `translations.en.defaultTaskTemplates`
- `translations.vi.defaultTaskTemplates`

Used by:

- `HomeScreen`
- default task generation
- suggested task presets

### `app_content/coach`

Required fields:

- `translations.en.welcomeMessage`
- `translations.vi.welcomeMessage`
- `translations.en.promptChips`
- `translations.vi.promptChips`

Used by:

- `Coach`

### `app_content/onboarding`

Required fields for each language:

- `stepTitles`
- `goals`
- `fitnessLevels`
- `preferredTimes`
- `durations`
- `equipments`
- `nutritionStyles`
- `workoutDays`
- `restrictions`
- `reminders`

Each option item must define:

- `value`
- `label`

Optional:

- `description`

Used by:

- `OnboardingScreen`
- onboarding value persistence
- `PlanPreviewScreen` label resolution through shared content

### `app_content/practice_categories/items/*`

Required fields:

- `id`
- `bodyPartKeys`
- `assetImage`
- `order`
- `labels.en`
- `labels.vi`

Used by:

- `PlanScreen`
- category list filtering

### `app_content/exercise_prescriptions/items/*`

Required fields:

- `exerciseId`
- `rules`

Optional translated note:

- `translations.en.note`
- `translations.vi.note`

Each rule supports:

- `goal`
- `fitnessLevels`
- `equipments`
- `minWeightKg`
- `maxWeightKg`
- `sets`
- `reps`
- `durationSeconds`
- `targetWeightMode`
- `fixedTargetWeightKg`
- `bodyWeightMultiplier`
- `minSuggestedWeightKg`
- `maxSuggestedWeightKg`

Rule precedence:

1. match `exerciseId`
2. filter by `goal`, `fitnessLevel`, `equipment`
3. filter by user `weightKg`
4. resolver picks the first best match after scoring specificity

Used by:

- `CategoryExerciseList`
- `ExerciseDetail`
- quick workout generation
- starter-plan exercise materialization

### `app_content/behavior/items/home`

Required fields:

- `mealTargetPerDay`
- `waterTargetMl`

Used by:

- `HomeScreen`

### `app_content/behavior/items/track`

Required fields:

- `mealTargetPerDay`
- `activeMinutesPerWorkout`

Used by:

- `TrackScreen`

### `app_content/behavior/items/quick_workout`

Required fields:

- `targetExerciseCount`
- `preferredBodyPartOrder`
- `defaultDurationSeconds`
- `defaultSets`
- `translations.en.caloriesPerMinute`
- `translations.vi.caloriesPerMinute`

Used by:

- `WorkoutSessionViewModel`

### `starter_plan_templates/*`

Required fields:

- `goal`
- `fitnessLevels`
- `equipments`
- `translations.en.planMeta`
- `translations.vi.planMeta`
- `translations.en.preview`
- `translations.vi.preview`
- `translations.en.scheduledWorkoutTemplates`
- `translations.vi.scheduledWorkoutTemplates`
- `scheduledWorkoutTemplates.exercises`

Used by:

- `PlanPreviewScreen`
- `FirebaseUserRemoteDataSource`
- `StarterPlanBuilder`

## Validation workflow

Run before seeding:

```bash
node scripts/verify_firebase_content.mjs --seed scripts/firebase_content_seed.json
```

The verifier checks:

- missing `en/vi` translations
- broken onboarding option lists
- missing category labels or body-part mappings
- invalid behavior config values
- exercise prescription overlap and invalid ranges
- missing prescription coverage for starter-plan exercises

## Seed workflow

```bash
node scripts/seed_firebase_content.mjs --seed scripts/firebase_content_seed.json --project-id fir-18934
```

## Admin smoke flow

1. Edit the seed or Firestore document.
2. Run the verifier.
3. Seed to Firebase.
4. Open `Home`, `Coach`, `Plan`, `Onboarding`, `Plan Preview`, `Exercise Detail`, and a free workout session.
5. Confirm the updated content is visible.
6. Disable network or remove the remote doc to confirm local fallback still renders.
